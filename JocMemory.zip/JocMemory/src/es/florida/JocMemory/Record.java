package es.florida.JocMemory;


public class Record {
	private String id;
	private String usuario;
	private int dificultad;
	private String timeStamp;
	private int duracion;
	
	public Record( String usuario, int dificultad, String timeStamp, int duracion) {
		super();
		//this.id = id;
		this.usuario = usuario;
		this.dificultad = dificultad;
		this.timeStamp = timeStamp;
		this.duracion = duracion;
	}

	public Record() {
		super();
	}

	public String getId() {
		return id;
	}

	public String getUsuario() {
		return usuario;
	}

	public int getDificultad() {
		return dificultad;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public int getDuracion() {
		return duracion;
	}
	
	
	
}

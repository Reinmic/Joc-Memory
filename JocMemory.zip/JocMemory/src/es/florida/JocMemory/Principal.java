package es.florida.JocMemory;

import java.io.IOException;

import es.florida.JocMemory.*;


public class Principal {

	public static void main(String[] args) throws IOException {
		
		Model m = new Model();
		Vista v = new Vista();
		Login l = new Login();
		@SuppressWarnings("unused")
		Controlador c = new Controlador(m, v);
	}

}

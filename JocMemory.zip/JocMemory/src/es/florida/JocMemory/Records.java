package es.florida.JocMemory;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Component;
import javax.swing.table.TableModel;

public class Records extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private static final Font font = new Font("Consolas", Font.PLAIN, 14);
	private JTextField txtNombrePeces;
	private JTextField txtFitxer;
	private JTable tabla;
	private static DefaultTableModel tableModel2x4;
	private static DefaultTableModel tableModel4x4;
	private JButton tornar;
	private JPanel centerPanel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Records frame = new Records();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Records() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 738, 552);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		centerPanel = new JPanel();
		contentPane.add(centerPanel, BorderLayout.CENTER);
		centerPanel.setLayout(null);

		tableModel2x4 = new DefaultTableModel();
		tabla = new JTable(tableModel2x4);

		JScrollPane scrollPane2x4 = new JScrollPane(tabla);
		scrollPane2x4.setBounds(12, 86, 330, 271);
		centerPanel.add(scrollPane2x4);
		
		tableModel4x4 = new DefaultTableModel();
		tabla = new JTable(tableModel4x4);

		JScrollPane scrollPane4x4 = new JScrollPane(tabla);
		scrollPane4x4.setBounds(366, 86, 330, 271);
		centerPanel.add(scrollPane4x4);

		tornar = new JButton("Tornar");
		tornar.setBounds(186, 374, 341, 30);
		tornar.setFont(font);
		centerPanel.add(tornar);
		
		JLabel lblrECORDS = new JLabel("RECORDS");
		lblrECORDS.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblrECORDS.setBounds(292, 34, 121, 27);
		centerPanel.add(lblrECORDS);

	}

	
		public void plenalTableModel2x4(List<Record> records) {
			//System.out.println(records.size());
			
			String[] nomColumnes = new String[4];

			nomColumnes[0] = "Usuario";
			nomColumnes[1] = "Dificultad";
			nomColumnes[2] = "Time Stamp";
			nomColumnes[3] = "Temps";

			tableModel2x4.setColumnIdentifiers(nomColumnes);

			for (int i = 0; i < records.size(); i++) {
				
				Vector<Object> fila = new Vector<>();

				fila.add(records.get(i).getUsuario()); 
				fila.add(records.get(i).getDificultad());
				fila.add(records.get(i).getTimeStamp());
				fila.add(records.get(i).getDuracion());
				
				tableModel2x4.addRow(fila);
			}
		
	}
		
		public void plenalTableModel4x4(List<Record> records) {
			String[] nomColumnes = new String[4];

			nomColumnes[0] = "Usuario";
			nomColumnes[1] = "Dificultad";
			nomColumnes[2] = "Time Stamp";
			nomColumnes[3] = "Temps";

			tableModel4x4.setColumnIdentifiers(nomColumnes);

			for (int i = 0; i < records.size(); i++) {
				
				Vector<Object> fila = new Vector<>();

				fila.add(records.get(i).getUsuario()); 
				fila.add(records.get(i).getDificultad());
				fila.add(records.get(i).getTimeStamp());
				fila.add(records.get(i).getDuracion());
				
				tableModel4x4.addRow(fila);
			}
		
	}

		public JButton getTornar() {
			return tornar;
		}
}

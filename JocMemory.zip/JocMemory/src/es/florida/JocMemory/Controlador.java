package es.florida.JocMemory;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Controlador {

	private Model model;
	private Vista vista;
	boolean acabar = false;
	private boolean conectat = false;

	private List<Card> cartes;
	JButton[] botons;
	ImageIcon revers;
	List<Card> apretats = new ArrayList<Card>();

	boolean vistaHecha = true;
	private String usuari;
	private int dificultad;
	public int relontge = 0;

	public Controlador(Model model, Vista vista) throws IOException {
		super();

		this.model = model;
		this.vista = vista;
		botons = vista.getButtons();
		
		model.cargarImagens();

		vista.getLoginButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Login login = new Login();
				login.setVisible(true);
				login.getBtnAceptar().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {

						String username = login.getTxtNomUsuari().getText();
						char[] passwordChars = login.getTxtContra().getPassword();
						String password = new String(passwordChars);
						usuari = username;
						if (model.logIn(username, password)) {
							JOptionPane.showMessageDialog(null, "Inici de sesió exitos");
							conectat = true;
							login.dispose();
							vista.getPlayButton().setEnabled(true);
							vista.getHallofFameButton().setEnabled(true);
							vista.getLoginButton().setEnabled(false);
							vista.getRegisterButton().setEnabled(false);

						} else {
							JOptionPane.showMessageDialog(null,
									"Inici de sesió fallit. Verifica les teues credencials.");
						}

					}
				});
			}
		});

		vista.getRegisterButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Registre registre = new Registre();
				registre.setVisible(true);
				registre.getRegistreButton().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {

						String nomUsuari = registre.getUsuari().getText();
						char[] contra = registre.getUsuariContra().getPassword();
						String contraDescifra = new String(contra);
						char[] contraConfirm = registre.getUsuariConfirmaCotnra().getPassword();
						String contraConfirmDescifra = new String(contraConfirm);

						if (contraDescifra.equals(contraConfirmDescifra)) {
							if (!model.existeixUsuari(nomUsuari)) {
								model.crearUsuari(nomUsuari, contraDescifra);
								JOptionPane.showMessageDialog(null, "Registro exitoso");
								registre.dispose();
							} else {
								JOptionPane.showMessageDialog(null,
										"El usuari ja existeix. Introduix un altre nom d'usuari.");
							}
						} else {
							JOptionPane.showMessageDialog(null, "Les contrasenyes no coincideixen.");
						}

					}
				});
			}
		});

		vista.getPlayButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TipusJoc tipusJoc = new TipusJoc();
				tipusJoc.setVisible(true);
				tipusJoc.getFacil().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						try {
							iniciJoc(4, tipusJoc);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

					}
				});
				tipusJoc.getDificil().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						try {
							iniciJoc(8, tipusJoc);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
			}
		});

		vista.getComensarButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				acabar = false;
				relontge = 0;
				iniciarRelontge();
				for(int i=0;i<vista.buttons.length;i++) {
					vista.buttons[i].setEnabled(true);
				}
				vista.getComensarButton().setEnabled(false);
			}
		});
		vista.getHallofFameButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Records records = new Records();
				records.setVisible(true);
				records.plenalTableModel2x4(model.carregarRecords2x4());
				records.plenalTableModel4x4(model.carregarRecords4x4());
				records.getTornar().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						records.dispose();

					}
				});
			}
		});

		refrescar();

		for (int i = 0; i < vista.buttons.length; i++) {
			final int indice = i;

			botons[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {

					cartes.get(indice).apretar();
					refrescar();
					apretats.add(cartes.get(indice));
					if (apretats.size() == 2) {
						if (apretats.get(0).getId() == apretats.get(1).getId()) {
							apretats.get(0).setParellaCompleta(true);
							apretats.get(1).setParellaCompleta(true);
						} else {
							apretats.get(0).setApretat(false);
							apretats.get(1).setApretat(false);
							refrescarAtrasado();
						}
						apretats.clear();
					}

					if (haAcabat()) {
						acabar = true;
						vista.getSaveButton().setEnabled(true);
					}
					;
				}
			});

			vista.getSaveButton().addActionListener(new ActionListener() {
				// @Override
				public void actionPerformed(ActionEvent e) {

					if (vista.getSaveButton().isEnabled()) {
						Record record = new Record(usuari, dificultad, model.timeStamp(), relontge);

						model.save(record);
					}

					vista.getSaveButton().setEnabled(false);
				}
			});
			vista.addWindowListener(new WindowAdapter() {
	            @Override
	            public void windowClosing(WindowEvent e) {
	                model.borrarImagenes();
	            }
	        });
		}

	};

	/**
	 * Crea un fil per a que es voltegen les cartes al ser incorrectes de forma no instantanea
	 */
	public void refrescarAtrasado() {
		Timer t = new Timer(this, true);
		Thread fil = new Thread(t);
		fil.start();
	}

	/**
	 * Funcio que comprova si s'ha acabt la partida
	 * @return
	 */
	public boolean haAcabat() {
		boolean haAcabat = true;
		for (int i = 0; i < cartes.size(); i++) {
			if (!cartes.get(i).isParellaCompleta()) {
				haAcabat = false;
				break;
			}
		}
		return haAcabat;
	}

	/**
	 * Inicia el components necesaris per a començar el joc
	 * @param nombreCartes
	 * @param tipusJoc
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	public void iniciJoc(int nombreCartes, TipusJoc tipusJoc) throws NumberFormatException, IOException {
		dificultad = nombreCartes*2;
		Vista.setLblTemp("Temps: x");
		cartes = model.carregarCartes(nombreCartes);
		vista.getSaveButton().setEnabled(false);
		revers = model.carregarImatgeRevers();
		refrescar();
		for(int i=0;i<vista.buttons.length;i++) {
			vista.buttons[i].setEnabled(false);
		}
		vista.getComensarButton().setEnabled(true);
		tipusJoc.dispose();
	}

	/**
	 * Refresca les cartes al apretar a les cartes segons siga una combinacio correcta o no
	 */
	public void refrescar() {
		int nombreCartes;
		if (cartes == null) {
			nombreCartes = 0;
		} else {
			nombreCartes = cartes.size();
		}

		for (int i = 0; i < vista.buttons.length; i++) {
			if (i < nombreCartes) {
				botons[i].setVisible(true);
				if (!cartes.get(i).isParellaCompleta()) {
					if (cartes.get(i).isApretat()) {
						botons[i].setIcon(cartes.get(i).getImatge());
					} else {
						botons[i].setIcon(revers);
					}
				}
			} else {
				botons[i].setVisible(false);
			}

		}

	}

	/**
	 * Inicia el relontge de la partida
	 */
	public void iniciarRelontge() {
		Timer t = new Timer(this);
		Thread fil = new Thread(t);
		fil.start();
	}

}

package es.florida.JocMemory;

import javax.imageio.ImageIO;
import javax.swing.*;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.Font;

public class Vista extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton hallofFameButton;
    private JButton loginButton;
    private JButton registerButton;
    private JButton playButton;
    private JButton saveButton;
    private JButton comensarButton;
    private JButton image15Button;
    private JButton image16Button;
    private JButton image14Button;
    private JButton image13Button;
    private JButton image9Button;
    private JButton image5Button;
    private JButton image1Button;
    private JButton image2Button;
    private JButton image6Button;
    private JButton image10Button;
    private JButton image11Button;
    private JButton image12Button;
    private JButton image8Button;
    private JButton image7Button;
    private JButton image3Button;
    private JButton image4Button;
    
    public JButton[] buttons ;
    private static JLabel lblTemp;
    

    public Vista() {


        this.setTitle("Aplicación de Gestión de Base de Datos");
        this.setSize(828, 612);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        hallofFameButton = new JButton("Hall of Fame");
        hallofFameButton.setBounds(10, 535, 150, 30);
        hallofFameButton.setEnabled(false);

        loginButton = new JButton("Login");
        loginButton.setBounds(10, 76, 150, 30);

        registerButton = new JButton("Register");
        registerButton.setBounds(10, 36, 150, 30);

        playButton = new JButton("Play");
        playButton.setBounds(10, 255, 150, 30);
        playButton.setEnabled(false);

        // Agregar componentes al formulario
        getContentPane().add(hallofFameButton);
        getContentPane().add(loginButton);
        getContentPane().add(registerButton);
        getContentPane().add(playButton);
        
        saveButton = new JButton("Save");
        saveButton.setBounds(10, 295, 150, 30);
        getContentPane().add(saveButton);
        saveButton.setEnabled(false);
        
        image15Button = new JButton("");
        image15Button.setBounds(534, 437, 128, 128);
        getContentPane().add(image15Button);
        
        image16Button = new JButton("");
        image16Button.setBounds(672, 437, 128, 128);
        getContentPane().add(image16Button);
        
        image14Button = new JButton("");
        image14Button.setBounds(396, 437, 128, 128);
        getContentPane().add(image14Button);
        
        image13Button = new JButton("");
        image13Button.setBounds(263, 437, 128, 128);
        getContentPane().add(image13Button);
        
        image9Button = new JButton("");
        image9Button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        image9Button.setBounds(263, 300, 128, 128);
        getContentPane().add(image9Button);
        
        image5Button = new JButton("");
        image5Button.setBounds(263, 163, 128, 128);
        getContentPane().add(image5Button);
        
        image1Button = new JButton("");
        image1Button.setBounds(263, 25, 128, 128);
        getContentPane().add(image1Button);
        
        image2Button = new JButton("");
        image2Button.setBounds(396, 27, 128, 128);
        getContentPane().add(image2Button);
        
        image6Button = new JButton("");
        image6Button.setBounds(396, 162, 128, 128);
        getContentPane().add(image6Button);
        
        image10Button = new JButton("");
        image10Button.setBounds(396, 299, 128, 128);
        getContentPane().add(image10Button);
        
        image11Button = new JButton("");
        image11Button.setBounds(534, 300, 128, 128);
        getContentPane().add(image11Button);
        
        image12Button = new JButton("");
        image12Button.setBounds(672, 299, 128, 128);
        getContentPane().add(image12Button);
        
        image8Button = new JButton("");
        image8Button.setBounds(672, 163, 128, 128);
        getContentPane().add(image8Button);
        
        image7Button = new JButton("");
        image7Button.setBounds(534, 163, 128, 128);
        getContentPane().add(image7Button);
        
        image3Button = new JButton("");
        image3Button.setBounds(534, 27, 128, 128);
        getContentPane().add(image3Button);
        
        image4Button = new JButton("");
        image4Button.setBounds(672, 27, 128, 128);
        getContentPane().add(image4Button);
        
        lblTemp = new JLabel("Temps: x");
        lblTemp.setFont(new Font("Tahoma", Font.BOLD, 13));
        lblTemp.setBounds(10, 139, 75, 30);
        getContentPane().add(lblTemp);
        
        comensarButton = new JButton("Començar");
        comensarButton.setEnabled(false);
        comensarButton.setBounds(10, 335, 150, 30);
        getContentPane().add(comensarButton);

        buttons = new JButton[]{
    	        image1Button, image2Button, image3Button, image4Button,
    	        image5Button, image6Button, image7Button, image8Button,
    	        image9Button, image10Button, image11Button, image12Button,
    	        image13Button, image14Button, image15Button, image16Button
    	    };
        
        this.setVisible(true);
    }


	public JButton[] getButtons() {
		return buttons;
	}


	public JButton getHallofFameButton() {
		return hallofFameButton;
	}


	public JButton getLoginButton() {
		return loginButton;
	}


	public JButton getRegisterButton() {
		return registerButton;
	}


	public JButton getPlayButton() {
		return playButton;
	}
	
	public JButton getSaveButton() {
		return saveButton;
	}

	public JButton getComensarButton() {
		return comensarButton;
	}


	public static void setLblTemp(String temps) {
		lblTemp.setText( temps);
	}
}
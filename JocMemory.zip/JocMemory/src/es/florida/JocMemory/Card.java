package es.florida.JocMemory;

import javax.swing.ImageIcon;

public class Card {
	private int id;
	private ImageIcon imatge;
	private boolean apretat=false;
	private boolean parellaCompleta=false;
	
	public Card(int id,ImageIcon imatge) {
		
		this.id = id;
		this.imatge=imatge;
	}

	public boolean isApretat() {
		return apretat;
	}

	public void setApretat(boolean apretat) {
		this.apretat = apretat;
	}

	public boolean isParellaCompleta() {
		return parellaCompleta;
	}

	public void setParellaCompleta(boolean parellaCompleta) {
		this.parellaCompleta = parellaCompleta;
	}

	public int getId() {
		return id;
	}

	public ImageIcon getImatge() {
		return imatge;
	}
	
	
	public void apretar() {
		apretat=!apretat;
	}
	
	
}

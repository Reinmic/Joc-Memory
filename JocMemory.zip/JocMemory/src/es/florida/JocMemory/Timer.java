package es.florida.JocMemory;

public class Timer extends Thread  {
	Controlador controlador;
	private boolean refrescar = false;
	

	public Timer(Controlador controlador) {
		super();
		this.controlador = controlador;
	
	}

	public Timer(Controlador controlador, boolean refrescar) {
		super();
		this.controlador = controlador;
		this.refrescar = refrescar;
	}

	
	public void run() {
		if (refrescar == true) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			controlador.refrescar();
		} else {
			while (!controlador.acabar) {
				Vista.setLblTemp("Temps: "+controlador.relontge);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				controlador.relontge++;

			}
		}

	}
}

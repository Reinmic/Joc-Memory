package es.florida.JocMemory;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.*;

public class TipusJoc extends JFrame {

	private static final long serialVersionUID = 1L;
	private JButton facil;
	private JButton dificil;
	private JPanel contentPane;
	private JPanel centerPanel;
	private static Font font = new Font("Consolas", Font.PLAIN, 14);

	
	public TipusJoc() {
		setTitle("Elecciò de dificultat");
		setBounds(100, 100, 338, 252);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		centerPanel = new JPanel();
		contentPane.add(centerPanel, BorderLayout.CENTER);
		centerPanel.setLayout(null);

		

		facil = new JButton("Facil");
		facil.setBounds(58, 77, 200, 30);
		facil.setFont(font);
		centerPanel.add(facil);
		
		dificil = new JButton("Dificil");
		dificil.setBounds(58, 130, 200, 30);
		dificil.setFont(font);
		centerPanel.add(dificil);
		
		JLabel lblNewLabel = new JLabel("Selecciona el nivell");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(87, 33, 137, 32);
		centerPanel.add(lblNewLabel);
		

	}


	public JButton getFacil() {
		return facil;
	}


	public JButton getDificil() {
		return dificil;
	}
}
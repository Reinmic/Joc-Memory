package es.florida.JocMemory;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.JSONArray;
import org.json.JSONObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.io.ByteArrayInputStream;
import org.apache.commons.codec.binary.Base64;
//import java.nio.file.File;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Model {

	private String collectionRecords;
	private String collectionUsers;
	private String collectionImagenes;

	MongoClient mongoClient; 
	MongoDatabase database;
	

	public Model() {
		carregaDatosJson();
	}

	/**
	 * Carrega les dades necesaries per a manipular la base de dades del fitxer Connexio
	 */
	public void carregaDatosJson() {
		try {

			String jsonString = new String(Files.readAllBytes(Paths.get("src/Connexio.json")));

			JSONArray jsonArray = new JSONArray(jsonString);

			for (int i = 0; i < jsonArray.length(); i++) {
				JSONObject jsonObject = jsonArray.getJSONObject(i);

				
				String ip = jsonObject.getString("ip");
				int port = jsonObject.getInt("port");
				mongoClient = new MongoClient(ip, port);
				database = mongoClient.getDatabase(jsonObject.getString("database"));
				collectionRecords = jsonObject.getString("collection_records");
				collectionUsers = jsonObject.getString("collection_users");
				collectionImagenes = jsonObject.getString("collection_imagenes");

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Extrau de la base de dades la informacia dels records amb dificultat sencilla i la fica en una llista
	 * @return llista de records nivell sencill
	 */
	public List<Record> carregarRecords2x4() {
		List<Record> records = new ArrayList<Record>();
		MongoCollection<Document> coleccion = database.getCollection(collectionRecords);
		MongoCursor<Document> cursor = coleccion.find(eq("dificultad", 8)).iterator();
		while (cursor.hasNext()) {
			System.out.println("i");
			JSONObject obj = new JSONObject(cursor.next().toJson());
			Record record = new Record(obj.getString("usuario"), obj.getInt("dificultad"), obj.getString("timestamp"),obj.getInt("duracion"));
			records.add(record);
		}
		
		Collections.sort(records, Comparator.comparingInt(Record::getDuracion));
		
		System.out.println(records.size());
		return records;
	}

	/**
	 * Extrau de la base de dades la informacia dels records amb dificultat dificil i la fica en una llista de records
	 * @return llista de records nivell dificil
	 */
	public List<Record> carregarRecords4x4() {

		List<Record> records = new ArrayList<Record>();
		MongoCollection<Document> coleccion = database.getCollection(collectionRecords);
		MongoCursor<Document> cursor = coleccion.find(eq("dificultad", 16)).iterator();
		while (cursor.hasNext()) {

			JSONObject obj = new JSONObject(cursor.next().toJson());
			Record record = new Record(obj.getString("usuario"), obj.getInt("dificultad"), obj.getString("timestamp"),
					obj.getInt("duracion"));
			records.add(record);
		}
		Collections.sort(records, Comparator.comparingInt(Record::getDuracion));
		return records;
	}

	/**
	 * Agafa la informacio creada al finalitzar al joc per a juardarla
	 * @param record
	 */
	public void save(Record record) {
		MongoCollection<Document> coleccion = database.getCollection(collectionRecords);
		Document doc = new Document();
		System.out.println(record.getUsuario());
		System.out.println(record.getDuracion());
		doc.append("_id", new ObjectId());
		doc.append("usuario", record.getUsuario());
		doc.append("dificultad", record.getDificultad());
		doc.append("timestamp", record.getTimeStamp());
		doc.append("duracion", record.getDuracion());
		coleccion.insertOne(doc);
	}

	/***
	 * Extrau de la base de dades si existeix un usuari 
	 * @param usuari 
	 * @return boolean
	 */
	public boolean existeixUsuari(String usuari) {

		MongoCollection<Document> coleccion = database.getCollection(collectionUsers);
		MongoCursor<Document> cursor = coleccion.find(eq("user", usuari)).iterator();

		if (cursor.hasNext()) {

			return true;
		}
			
		return false;

	}

	/**
	 * Crea un usuari a la base de dades donat un nom d'usuari i una contrasenya
	 * @param usuari
	 * @param contrasenya
	 */
	public void crearUsuari(String usuari, String contrasenya) {

		MongoCollection<Document> coleccion = database.getCollection(collectionUsers);
		Document doc = new Document();

		doc.append("_id", new ObjectId());
		doc.append("user", usuari);
		doc.append("pass", encriptaContrasenya(contrasenya));
		coleccion.insertOne(doc);

	}

	/**
	 * Carrega les imatges de la base de dades i les crea en local
	 * @throws IOException
	 */
	public void cargarImagens() throws IOException {
		MongoCollection<Document> coleccion = database.getCollection(collectionImagenes);
		MongoCursor<Document> cursor = coleccion.find().iterator();
		while (cursor.hasNext()) {

			JSONObject obj = new JSONObject(cursor.next().toJson());
			byte[] btDataFile = Base64.decodeBase64(obj.getString("base64"));
			BufferedImage imatge = ImageIO.read(new ByteArrayInputStream(btDataFile));
			imatge.getScaledInstance(-1, 400, java.awt.Image.SCALE_SMOOTH);
			ImageIO.write(imatge, "jpg", new File("./src/img/" + obj.getString("id")));
			System.out.println("si");

		}

	}
	
	/**
	 * Elimina les imatges en local per a lliberar espai
	 */
	public void borrarImagenes() {
		File directori = new File("./src/img");
		File[] imatges = directori.listFiles();

		for (int i = 0; i < imatges.length; i++) {
			imatges[i].delete();
		}
	}

	/**
	 * Crea una llista de numeros aleatoris de un valor maxim sense que es repetixquen
	 * @param numElements
	 * @param valorMaxElement
	 * @return Llista de nombres, String
	 */
	public List<String> arrayNumRandoms(int numElements, int valorMaxElement) {

		List<String> arrayRandoms = new ArrayList<>();

		while (arrayRandoms.size() < numElements) {
			double num = ((Math.random() * valorMaxElement + 1) - 1);
			int numInt = (int) num;
			String numString = numInt + "";
			boolean esta = false;
			if (arrayRandoms.size() > 0) {

				for (int i = 0; i < arrayRandoms.size(); i++) {
					if (arrayRandoms.get(i).equals(numString))
						esta = true;
				}
				if (!esta)
					arrayRandoms.add(numString);
			} else {
				arrayRandoms.add(numString);
			}
		}

		return arrayRandoms;

	}

	/**
	 * Ordena un array de forma aleatoria
	 * @param arrayRandoms
	 */
	public void reordenar(List<String> arrayRandoms) {
		List<String> arrayRandomsCopy = new ArrayList<>(arrayRandoms);

		List<String> arrayRandoms2 = new ArrayList<>();

		while (arrayRandomsCopy.size() > 0) {
			double num = ((Math.random() * arrayRandomsCopy.size() + 1) - 1);
			int numInt = (int) num;
			arrayRandoms2.add(arrayRandomsCopy.get(numInt));
			arrayRandomsCopy.remove(numInt);
		}

		for (int i = 0; i < arrayRandoms2.size(); i++) {
			arrayRandoms.set(i, arrayRandoms2.get(i));
		}

	}

	/**
	 * Crea una llista de cartes amb la parella de forma aleatoria 
	 * @param nombreCartes
	 * @return llista de cartes
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	public List<Card> carregarCartes(int nombreCartes) throws NumberFormatException, IOException {

		List<Card> cards = new ArrayList<Card>();

		List<String> index = arrayNumRandoms(nombreCartes, 8);

		int tamany = index.size();
		for (int i = 0; i < tamany; i++) {
			index.add(index.get(i));

		}

		reordenar(index);

		File directori = new File("./src/img");
		File[] imatges = directori.listFiles();

		for (int i = 0; i < index.size(); i++) {
			Image imatge = ImageIO.read(imatges[Integer.parseInt(index.get(i))]);
			ImageIcon imatgeIcona = new ImageIcon(imatge);
			Card card = new Card(Integer.parseInt(index.get(i)), imatgeIcona);
			cards.add(card);
		}

		return cards;
	}

	/**
	 * Carrega el revers de les cartes
	 * @return
	 * @throws IOException
	 */
	public ImageIcon carregarImatgeRevers() throws IOException {
		File directoriImatge = new File("./src/es/florida/JocMemory/backCard.png");

		Image imatge = ImageIO.read(directoriImatge);
		Image imatgeEscalada = imatge.getScaledInstance(100, 128, Image.SCALE_SMOOTH);

		return new ImageIcon(imatgeEscalada);

	}

	/**
	 * Comprova que el login siga correcte
	 * @param usuari
	 * @param contrasenya
	 * @return
	 */
	public boolean logIn(String usuari, String contrasenya) {

		MongoCollection<Document> coleccion = database.getCollection(collectionUsers);
		MongoCursor<Document> cursor = coleccion
				.find(and(eq("user", usuari), eq("pass", encriptaContrasenya(contrasenya)))).iterator();
		if (cursor.hasNext())
			return true;
		return false;
	}

	/**
	 * Crea un timeStamp del moment actual
	 * @return
	 */
	public String timeStamp() {
		Date date = new Date();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");

		return dateFormat.format(date);
	}

	/**
	 * Encripta la contrasenya
	 */
	private String encriptaContrasenya(String contrasenya) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}

		byte[] hash = md.digest(contrasenya.getBytes());
		StringBuffer sb = new StringBuffer();

		for (byte b : hash) {
			sb.append(String.format("%02x", b));
		}

		return sb.toString();
	}
}

package es.florida.JocMemory;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;

public class Registre extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usuari;
	private JPasswordField usuariContra;
	private JPasswordField usuariConfirmaCotnra;
	private JButton newRegisterButton;

	/**
	 * Create the frame.
	 */
	public Registre() {
		setTitle("Registre");
		setBounds(100, 100, 352, 375);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		usuari = new JTextField();
		usuari.setBounds(55, 56, 209, 19);
		contentPane.add(usuari);
		usuari.setColumns(10);
		
		usuariContra = new JPasswordField(20);
		usuariContra.setColumns(10);
		usuariContra.setBounds(55, 128, 209, 19);
		contentPane.add(usuariContra);
		
		usuariConfirmaCotnra = new JPasswordField(20);
		usuariConfirmaCotnra.setColumns(10);
		usuariConfirmaCotnra.setBounds(55, 191, 209, 19);
		contentPane.add(usuariConfirmaCotnra);
		
		newRegisterButton = new JButton("Register");
		newRegisterButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		newRegisterButton.setBounds(55, 256, 209, 38);
		contentPane.add(newRegisterButton);
		
		JLabel registerUsuariLbl = new JLabel("Usuari:");
		registerUsuariLbl.setFont(new Font("Tahoma", Font.BOLD, 14));
		registerUsuariLbl.setBounds(132, 32, 132, 13);
		contentPane.add(registerUsuariLbl);
		
		JLabel registerContraLbl = new JLabel("Contrasemya:");
		registerContraLbl.setFont(new Font("Tahoma", Font.BOLD, 14));
		registerContraLbl.setBounds(110, 98, 132, 13);
		contentPane.add(registerContraLbl);
		
		JLabel registerConfirmaContraLbl = new JLabel("Confirmar Contrasenya:");
		registerConfirmaContraLbl.setFont(new Font("Tahoma", Font.BOLD, 14));
		registerConfirmaContraLbl.setBounds(79, 168, 209, 13);
		contentPane.add(registerConfirmaContraLbl);
		
	}

	public JTextField getUsuari() {
		return usuari;
	}

	public JPasswordField getUsuariContra() {
		return usuariContra;
	}

	public JPasswordField getUsuariConfirmaCotnra() {
		return usuariConfirmaCotnra;
	}

	public JButton getRegistreButton() {
		// TODO Auto-generated method stub
		return newRegisterButton;
	}
	
}
